const employeeType = {
  SET_CURRENT_EMPLOYEE_DETAILS: ' SET_CURRENT_EMPLOYEE_DETAILS',
  SET_SEARCH_EMPLOYEE_DETAILS: ' SET_SEARCH_EMPLOYEE_DETAILS',
  SET_Leave_post: ' SET_Leave_post',
}
export default employeeType;
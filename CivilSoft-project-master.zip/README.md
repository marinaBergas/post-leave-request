# CivilSoft Task Requirements

- Start build the web app as shown in design
- You may use one of JavaScript frame work (react/angular)
- Everythig has to be completely responsive 
- All form elements are required 
- Saving request redirect to grid screen and new request must be add to grid
`Note:` Advanced (you can edit any request that already saved in grid)
- You can add new request by clicking the plus top right button 

## Available Scripts

In the project directory, you can run:


### `npm run json-server`

Runs the json server on port 8000\

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

